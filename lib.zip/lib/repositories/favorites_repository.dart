import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:drift/drift.dart';
import 'package:flutter/foundation.dart';
import '../firebase/local_database.dart';
import '../models/cinema.dart';
import '../models/favorite_manager.dart';

class FavoritesRepository extends FavoriteManager {
  final AppDatabase _db;
  final _firestore = FirebaseFirestore.instance;
  String? _currentUserId;

  FavoritesRepository({required AppDatabase db}) : _db = db;

  void setCurrentUser(String? uid) => _currentUserId = uid;

  Future<void> init(String userId) async {
    _currentUserId = userId;
    final rows = await _db.getAllFavorites();
    clearList();
    for (final c in rows.map(_rowToCinema)) {
      addToList(c);
    }
    notifyListeners();
    await _syncFromFirestore(userId);
  }

  Future<void> _syncFromFirestore(String userId) async {
    final snap = await _firestore
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .get();
    await _db.clearFavorites();
    clearList();
    for (final doc in snap.docs) {
      final c = _docToCinema(doc.id, doc.data());
      addToList(c);
      await _db.insertFavorite(_toCompanion(c));
    }
    notifyListeners();
  }

  // 1-arg overrides — widgets call these without knowing about userId
  @override
  void toggleFavorite(Cinema cinema) {
    final uid = _currentUserId;
    if (uid == null) { super.toggleFavorite(cinema); return; }
    isFavorite(cinema) ? _remove(cinema, uid) : _add(cinema, uid);
  }

  @override
  void removeFavorite(Cinema cinema) {
    final uid = _currentUserId;
    if (uid == null) { super.removeFavorite(cinema); return; }
    _remove(cinema, uid);
  }

  @override
  void clearAll() {
    super.clearAll();
    _db.clearFavorites();
  }

  Future<void> _add(Cinema cinema, String userId) async {
    addToList(cinema);
    notifyListeners();
    await _db.insertFavorite(_toCompanion(cinema));
    await _firestore
        .collection('users').doc(userId).collection('favorites')
        .doc(cinema.id).set(_cinemaToMap(cinema));
  }

  Future<void> _remove(Cinema cinema, String userId) async {
    removeFromList(cinema);
    notifyListeners();
    await _db.deleteFavorite(cinema.id);
    await _firestore
        .collection('users').doc(userId).collection('favorites')
        .doc(cinema.id).delete();
  }

  FavoriteCinemasCompanion _toCompanion(Cinema c) => FavoriteCinemasCompanion(
    id: Value(c.id), name: Value(c.name), address: Value(c.address),
    attributes: Value(c.attributes), imageUrl: Value(c.imageUrl),
    imageCredits: Value(c.imageCredits), distance: Value(c.distance),
    rating: Value(c.rating),
  );

  Cinema _rowToCinema(FavoriteCinema r) =>
      Cinema(r.id, r.name, r.address, r.attributes, r.imageUrl,
          r.imageCredits, r.distance, r.rating, []);

  Cinema _docToCinema(String id, Map<String, dynamic> d) => Cinema(
    id,
    d['name']         as String? ?? '',
    d['address']      as String? ?? '',
    d['attributes']   as String? ?? '',
    d['imageUrl']     as String? ?? '',
    d['imageCredits'] as String? ?? '',
    (d['distance'] as num?)?.toDouble() ?? 0,
    (d['rating']   as num?)?.toDouble() ?? 0,
    [],
  );

  Map<String, dynamic> _cinemaToMap(Cinema c) => {
    'name': c.name, 'address': c.address, 'attributes': c.attributes,
    'imageUrl': c.imageUrl, 'imageCredits': c.imageCredits,
    'distance': c.distance, 'rating': c.rating,
  };
}