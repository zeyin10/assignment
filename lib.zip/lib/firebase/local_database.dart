import 'package:drift/drift.dart';
import 'database_connection.dart';

part 'local_database.g.dart';

class FavoriteCinemas extends Table {
  TextColumn get id           => text()();
  TextColumn get name         => text()();
  TextColumn get address      => text()();
  TextColumn get attributes   => text()();
  TextColumn get imageUrl     => text()();
  TextColumn get imageCredits => text()();
  RealColumn get distance     => real()();
  RealColumn get rating       => real()();
}

@DriftDatabase(tables: [FavoriteCinemas])
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.e);

  @override
  int get schemaVersion => 1;

  Future<List<FavoriteCinema>> getAllFavorites() =>
      select(favoriteCinemas).get();

  Future<void> insertFavorite(FavoriteCinemasCompanion entry) =>
      into(favoriteCinemas).insertOnConflictUpdate(entry);

  Future<void> deleteFavorite(String id) =>
      (delete(favoriteCinemas)..where((t) => t.id.equals(id))).go();

  Future<void> clearFavorites() => delete(favoriteCinemas).go();
}